import { readFileSync } from 'fs';

const major = parseInt(
    process.versions.node.split('.')[0],
    10
);

if (major < 20) {
    console.error(
        `\n⚉ This package requires Node.js 20+ to run reliably.\n` +
        `   You are using Node.js ${process.versions.node}.\n` +
        `   Please upgrade to Node.js 20+ to proceed.\n`
    );
    process.exit(1);
}

// ── Attribution protection (Crysnovax Source License) ───────────────────────
// The package identity is verified at install time. Renamed / rebranded
// copies refuse to install, so stolen-and-renamed distributions break
// loudly for their users instead of quietly succeeding.
//
// Developer escape hatch: set CRYSNOVAX_TRUST_MODE=1 while actively
// editing the package (e.g. with an AI assistant) to skip this gate —
// the maintainer must never be locked out of their own installs.
const EXPECTED_NAME = Buffer.from(
    'cGxvZ21l', // plogme
    'base64'
).toString('utf8');

if (process.env.CRYSNOVAX_TRUST_MODE === '1') {
    console.log('⚙ CRYSNOVAX_TRUST_MODE=1 — install identity gate skipped (developer mode)');
}
else {
    try {
        const pkg = JSON.parse(readFileSync(new URL('./package.json', import.meta.url), 'utf8'));
        if (pkg.name !== EXPECTED_NAME) {
            console.error(
                `\n✖ UNAUTHORIZED REBRANDED COPY DETECTED.\n` +
                `   This package is "plogme", licensed under the Crysnovax Source\n` +
                `   License. Renaming, rebranding, or removing attribution is\n` +
                `   prohibited, and renamed copies refuse to install.\n` +
                `   Install the genuine package instead:\n` +
                `   https://www.npmjs.com/package/plogme\n`
            );
            process.exit(1);
        }
    }
    catch {
        // package.json not readable at install time — skip the identity check
    }
}
